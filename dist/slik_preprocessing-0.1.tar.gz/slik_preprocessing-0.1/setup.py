from setuptools import setup

setup(name='slik_preprocessing',
      version='0.1',
      description='A data preprocessing tool',
      packages=['slik_preprocessing'],
      author = 'Adeshola Afolabi',
      zip_safe=False)